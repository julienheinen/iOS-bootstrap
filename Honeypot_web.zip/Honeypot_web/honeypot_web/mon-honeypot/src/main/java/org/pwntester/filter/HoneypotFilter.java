package org.pwntester.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HoneypotFilter implements Filter {

    // Liste de commandes connues
    private static final List<String> KNOWN_COMMANDS = Arrays.asList(
        "wget", "curl", "ping", "whoami", "id", "cat ", "ls ", "dir ", 
        "uname", "netcat", "nc ", "bash ", "python", "perl", "gcc", 
        "rm ", "echo", "nslookup", "tftp", "ftp", "ssh", "scp", "ip addr", "ifconfig"
    );

    public void init(FilterConfig filterConfig) throws ServletException {}

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String contentType = req.getHeader("Content-Type");

        if (contentType != null && (contentType.contains("%{") || contentType.contains("${") || contentType.contains("multipart/form-data"))) {
            
            if (contentType.startsWith("multipart/form-data") && !contentType.contains("ognl") && !contentType.contains("#")) {
                 chain.doFilter(request, response);
                 return;
            }

            String cmd = extractCommand(contentType);
            
            logAttack(req, cmd, contentType.length());

            res.setContentType("text/html;charset=UTF-8");
            PrintWriter out = res.getWriter();
            out.print(simulateShell(cmd));
            out.flush();
            
            return;
        }

        chain.doFilter(request, response);
    }

    private String extractCommand(String payload) {
        if (payload == null) return "null";

        Pattern pVar = Pattern.compile("#[a-zA-Z0-9_]+\\s*=\\s*['\"]([^'\"]{2,150}?)['\"]");
        Matcher mVar = pVar.matcher(payload);
        
        while (mVar.find()) {
            String val = mVar.group(1);
            
            if (val.contains("multipart/form-data")) continue;
            
            if (val.contains("ognl") || val.contains("opensymphony") || val.contains("DEFAULT_MEMBER_ACCESS")) continue;

            return val; 
        }


        Pattern pShell = Pattern.compile("(?:bash|sh|cmd(?:\\.exe)?)\\s*(?:-[a-zA-Z]+|/[a-zA-Z])\\s*['\"]?([^'\")]+)['\"]?");
        Matcher mShell = pShell.matcher(payload);
        if (mShell.find()) {
            return mShell.group(1);
        }

        Pattern pArray = Pattern.compile("new\\s+java\\.lang\\.String\\[\\]\\s*\\{.*?['\"]([^'\"]+)['\"]\\s*\\}");
        Matcher mArray = pArray.matcher(payload);
        if (mArray.find()) {
            return mArray.group(1);
        }

        Pattern pExec = Pattern.compile("exec\\s*\\(\\s*['\"]([^'\"]+)['\"]\\s*\\)");
        Matcher mExec = pExec.matcher(payload);
        if (mExec.find()) {
            return mExec.group(1);
        }

        String lowerPayload = payload.toLowerCase();
        for (String knownCmd : KNOWN_COMMANDS) {
            if (lowerPayload.contains(knownCmd)) {
                int idx = lowerPayload.indexOf(knownCmd);
                int end = Math.min(idx + 50, payload.length());
                String extracted = payload.substring(idx, end).replaceAll("[^a-zA-Z0-9 .:/_-]", "");
                return extracted + " (Heuristic)";
            }
        }

        if (payload.length() > 50) {
             return "Unknown Payload (Start: " + payload.substring(0, 30) + "...)";
        }
        return "Unknown Payload";
    }

    private void logAttack(HttpServletRequest req, String cmd, int payloadSize) {
        String ip = req.getRemoteAddr();
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        String safeCmd = cmd == null ? "" : cmd.replace("\"", "\\\"");
        String logEntry = "{" 
                + "\"timestamp\":\"" + time + "\", "
                + "\"app\":\"web-app\", "
                + "\"ip\":\"" + ip + "\", "
                + "\"event\":\"OGNL_COMMAND\", "
                + "\"CMD\":\"" + safeCmd + "\""
                + "}\n";

        try (FileWriter fw = new FileWriter("/var/log/commandes.log", true)) {
            fw.write(logEntry);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String simulateShell(String cmd) {
        String cleanCmd = cmd.toLowerCase().trim();
        if (cleanCmd.contains("whoami")) return "tomcat";
        if (cleanCmd.contains("id")) return "uid=1000(tomcat) gid=1000(tomcat) groups=1000(tomcat)";
        if (cleanCmd.contains("pwd")) return "/opt/tomcat/webapps/ROOT";
        if (cleanCmd.contains("ls")) return "index.jsp\nWEB-INF\nMETA-INF\nrobots.txt\nconfidential.xml";
        if (cleanCmd.contains("cat /etc/passwd")) return "root:x:0:0:root:/root:/bin/bash\ntomcat:x:1000:1000::/opt/tomcat:/bin/false";
        if (cleanCmd.contains("uname")) return "Linux SRV-PROD-01 5.4.0-104-generic #118-Ubuntu SMP Thu Mar 3 04:14:57 UTC 2022 x86_64";
        
        String displayCmd = cmd.replace(" (Heuristic)", "");
        return "/bin/sh: " + displayCmd + ": command not found";
    }

    public void destroy() {}
}
