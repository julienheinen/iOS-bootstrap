<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Upload Réussi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body { background-color: #f8f9fa; padding-top: 50px; }</style>
</head>
<body>
<div class="container">
    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-header bg-success text-white">
            <h4 class="mb-0">Succès !</h4>
        </div>
        <div class="card-body">
            <p class="lead">Le fichier a été reçu par le serveur.</p>
            <hr>
            <dl class="row">
                <dt class="col-sm-4">Nom du fichier :</dt>
                <dd class="col-sm-8"><s:property value="uploadFileName" /></dd>

                <dt class="col-sm-4">Type MIME :</dt>
                <dd class="col-sm-8"><s:property value="uploadContentType" /></dd>

                <dt class="col-sm-4">Description :</dt>
                <dd class="col-sm-8"><s:property value="caption" /></dd>
            </dl>
            <a href="upload.action" class="btn btn-outline-primary">Envoyer un autre fichier</a>
        </div>
    </div>
</div>
</body>
</html>
