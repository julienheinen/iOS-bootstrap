<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>UL - GTC Chaufferie Brabois [ADMIN]</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f2f5; margin: 0; }
        .header { background-color: white; padding: 15px 30px; border-bottom: 3px solid #fecb00; display: flex; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .logo-container { margin-right: 25px; padding-right: 25px; border-right: 1px solid #ddd; }
        .univ-logo { height: 70px; display: block; }
        .header-text h1 { margin: 0; font-size: 22px; color: #002d5c; text-transform: uppercase; letter-spacing: 0.5px; }
        .sub-header { font-size: 13px; color: #555; margin-top: 4px; font-weight: 500; }
        .main-container { display: flex; margin: 30px; gap: 20px; }
        .status-panel { width: 280px; background: #2c3e50; color: white; padding: 0; border-radius: 4px; overflow: hidden; height: fit-content; }
        .panel-header { background: #1a252f; padding: 12px 15px; font-weight: bold; border-bottom: 1px solid #34495e; font-size: 14px; }
        .status-item { padding: 12px 15px; border-bottom: 1px solid #34495e; font-size: 13px; }
        .label { display: block; color: #bdc3c7; font-size: 10px; text-transform: uppercase; margin-bottom: 2px;}
        .value { font-family: 'Consolas', monospace; font-weight: bold; font-size: 14px;}
        .status-ok { color: #2ecc71; }
        .status-warn { color: #f1c40f; }
        .status-crit { color: #e74c3c; animation: blink 2s infinite; }
        @keyframes blink { 50% { opacity: 0.5; } }
        .content-panel { flex-grow: 1; background: white; padding: 30px; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        h2 { margin-top: 0; border-bottom: 2px solid #eee; padding-bottom: 15px; font-size: 20px; color: #333; }
        .warning-box { background: #fff3cd; border-left: 5px solid #ffc107; color: #856404; padding: 15px; font-size: 14px; margin-bottom: 25px; }
        .form-group { margin-bottom: 20px; border: 1px dashed #ccc; padding: 20px; background: #fafafa; }
        input[type="file"] { width: 100%; }
        input[type="submit"] { background-color: #002d5c; color: white; border: none; padding: 10px 25px; font-weight: bold; cursor: pointer; border-radius: 3px; transition: background 0.2s; }
        input[type="submit"]:hover { background-color: #004494; }
        .footer { text-align: center; font-size: 11px; color: #999; margin-top: 50px; padding-bottom: 20px; }
        
        details { margin-top: 30px; border-top: 1px solid #eee; padding-top: 15px; }
        summary { cursor: pointer; color: #002d5c; font-weight: bold; font-size: 14px; outline: none; }
        .tools-links { margin-top: 10px; padding-left: 20px; }
        .tools-links a { color: #0056b3; text-decoration: none; display: block; margin-bottom: 5px; font-size: 13px; }
        .tools-links a:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <div class="header">
        <div class="logo-container">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Logo_Universit%C3%A9_de_Lorraine.svg/langfr-2560px-Logo_Universit%C3%A9_de_Lorraine.svg.png" alt="Logo Université de Lorraine" class="univ-logo">
        </div>
        <div class="header-text">
            <h1>Direction du Patrimoine Immobilier</h1>
            <div class="sub-header">Portail de Gestion Technique Centralisée (GTC) - Campus Sciences</div>
        </div>
    </div>

    <div class="main-container">
        <div class="status-panel">
            <div class="panel-header">ÉTAT DES FLUIDES (Temps Réel)</div>
            <div class="status-item"><span class="label">CONNEXION AUTOMATE</span><span class="value status-warn">DÉGRADÉE (Latence > 200ms)</span></div>
            <div class="status-item"><span class="label">TEMP. DÉPART CHAUFFAGE</span><span class="value">64.5 °C</span></div>
            <div class="status-item"><span class="label">PRESSION VASE EXPANSION</span><span class="value status-crit">0.8 Bar (SEUIL BAS)</span></div>
            <div class="status-item"><span class="label">DERNIÈRE SYNCHRO</span><span class="value">24/01/2026 11:42:12</span></div>
            <div class="status-item"><span class="label">SESSION ADMIN</span><span class="value">ACTIVE (RW)</span></div>
        </div>

        <div class="content-panel">
            <h2>Interface de Maintenance Automate</h2>

            <div class="warning-box">
                <strong>⚠️ AVERTISSEMENT DE SÉCURITÉ</strong><br>
                Cette interface permet la modification directe du firmware des contrôleurs de chauffage.
                Toute modification non autorisée sera signalée au service DSI et peut entraîner des poursuites.
                <br><br>
                <em>Erreur détectée : Le fichier de configuration actuel semble corrompu. Veuillez re-uploader une sauvegarde saine.</em>
            </div>

            <p style="margin-bottom: 10px;">Sélectionnez le binaire de mise à jour (.bin, .hex) ou le fichier de config (.conf) :</p>

            <s:form action="upload" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <s:file name="upload" cssStyle="margin-bottom: 10px;" />
                </div>
                <div style="text-align: right;">
                    <s:submit value="INITIALISER LA MISE À JOUR" />
                </div>
            </s:form>

            <details>
                <summary>Outils de Diagnostic Réseau (DSI)</summary>
                    <div class="tools-links">
                        <a href="<s:url value='/tools/network_diag.jsp'/>">
                            >> Test de connectivité (Ping / ICMP)
                        </a>
                        <a href="<s:url value='/tools/log_reader.jsp'/>">
                            >> Visualiseur de journaux système (Logs)
                        </a>
                    </div>
            </details>
            

        </div>
    </div>

    <div class="footer">
        Université de Lorraine - Direction du Patrimoine Immobilier (DPI)<br>
        34 Cours Léopold, 54000 Nancy | Système GTC v4.1.2 (Non-Patché)
    </div>

</body>
</html>
