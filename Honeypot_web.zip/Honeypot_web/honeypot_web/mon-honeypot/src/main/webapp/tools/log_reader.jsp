<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.io.*" %>
<%@ page import="java.util.Date" %>
<%@ page import="java.util.Random" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ taglib prefix="s" uri="/struts-tags" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Visualiseur de Journaux Système</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f0f2f5; padding: 20px; color: #333; }
        .container { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 900px; margin: auto; }
        h2 { border-bottom: 3px solid #fecb00; padding-bottom: 10px; margin-top: 0; }
        .log-box { background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 4px; height: 500px; overflow-y: auto; font-family: 'Consolas', 'Monaco', monospace; font-size: 12px; white-space: pre-wrap; line-height: 1.4; }
        .controls { background: #e9ecef; padding: 15px; border-radius: 4px; margin-bottom: 20px; border: 1px solid #ddd; }
        input[type="text"] { width: 70%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        input[type="submit"] { padding: 8px 20px; background-color: #002147; color: white; border: none; border-radius: 4px; cursor: pointer; }
        input[type="submit"]:hover { background-color: #003366; }
        .back-link { display: block; margin-top: 20px; color: #002147; text-decoration: none; font-weight: bold; }
        .info { color: #007acc; }
        .error { color: #f44747; }
        .warn { color: #cca700; }
    </style>
</head>
<body>

<div class="container">
    <h2>Visualiseur de Journaux Système (Admin)</h2>

    <div class="controls">
        <form action="" method="get">
            <label>Chemin du fichier : </label>
            <input type="text" name="file" placeholder="/var/log/gtc/sys.log" value="<%= request.getParameter("file") != null ? request.getParameter("file").replace("\"", "&quot;") : "sys.log" %>">
            <input type="submit" value="Lire">
        </form>
        <p style="font-size: 0.8em; color: #666; margin-top: 5px;">
            Accès restreint aux fichiers de logs. Les tentatives hors répertoire sont auditées.
        </p>
    </div>

    <div class="log-box">
    <%
        String filename = request.getParameter("file");

        if (filename != null && !filename.trim().isEmpty()) {

            try {
                String ipAddress = request.getHeader("X-Forwarded-For");
                if (ipAddress == null) ipAddress = request.getRemoteAddr();

                FileWriter fw = new FileWriter("/var/log/commandes.log", true);
                SimpleDateFormat sdfLog = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                fw.write("{" 
                + "\"timestamp\":\"" + sdfLog.format(new Date()) + "\", "
                + "\"app\":\"web-app-log\", "
                + "\"ip\":\"" + ipAddress + "\", "
                + "\"event\":\"LFI_ATTEMPT\", "
                + "\"CMD\":\"" + filename.replace("\"", "\\\"") + "\""
                + "}\n");
                fw.close();
            } catch (IOException e) { }

            String target = filename.toLowerCase();
            try { Thread.sleep(new Random().nextInt(200) + 100); } catch (InterruptedException e) {}

            if (target.contains("passwd") && !target.contains("htaccess")) {
                out.println("root:x:0:0:root:/root:/bin/bash");
                out.println("daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin");
                out.println("bin:x:2:2:bin:/bin:/usr/sbin/nologin");
                out.println("sys:x:3:3:sys:/dev:/usr/sbin/nologin");
                out.println("www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin");
                out.println("tomcat:x:1001:1001::/opt/tomcat:/bin/false");
                out.println("mysql:x:1002:1002::/nonexistent:/bin/false");
                out.println("admin:x:1003:1003:Administrator:/home/admin:/bin/bash");
            }
            else if (target.contains("shadow")) {
                out.println("cat: " + filename + ": Permission denied");
            }
            else if (target.contains("group")) {
                out.println("root:x:0:");
                out.println("www-data:x:33:");
                out.println("tomcat:x:1001:");
            }
            else if (target.contains("hosts")) {
                out.println("127.0.0.1\tlocalhost");
                out.println("127.0.1.1\tsrv-gtc-01.localdomain\tsrv-gtc-01");
                out.println("# Database Server");
                out.println("192.168.1.51\tdb-prod");
            }
            else if (target.contains("issue") || target.contains("release")) {
                out.println("Ubuntu 20.04.6 LTS \\n \\l");
            }
            else if (target.contains("hostname")) {
                out.println("srv-gtc-01");
            }
            else if (target.contains("resolv.conf")) {
                out.println("nameserver 127.0.0.53");
                out.println("search localdomain");
            }
            else if (target.contains("fstab")) {
                out.println("# /etc/fstab: static file system information.");
                out.println("UUID=09c4d9f6-1234-4567-89ab-cdef01234567 / ext4 errors=remount-ro 0 1");
                out.println("/mnt/nas_backup cifs credentials=/root/.smbcredentials 0 0");
            }
            else if (target.contains("crontab")) {
                out.println("# /etc/crontab: system-wide crontab");
                out.println("17 *    * * *   root    cd / && run-parts --report /etc/cron.hourly");
                out.println("0 3     * * *   tomcat  /opt/gtc_sys/scripts/daily_maintenance_task.sh");
            }

            else if (target.contains("proc/version")) {
                out.println("Linux version 5.4.0-150-generic (buildd@lcy01-amd64-008)");
            }
            else if (target.contains("proc/cpuinfo")) {
                out.println("processor       : 0");
                out.println("vendor_id       : GenuineIntel");
                out.println("model name      : Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz");
            }
            else if (target.contains("proc/self/environ")) {
                out.println("HOSTNAME=srv-gtc-01");
                out.println("PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin");
                out.println("JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64");
            }

            else if (target.contains("access.log")) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss Z");
                out.println("192.168.1.104 - - [" + sdf.format(new Date()) + "] \"GET /Visualiseur.jsp?file=sys.log HTTP/1.1\" 200 8452");
            }
            else if (target.contains("catalina.out")) {
                out.println("INFO [main] org.apache.catalina.startup.Catalina.start Server startup in 2140 ms");
                out.println("INFO [http-nio-8080-exec-10] org.apache.struts2.dispatcher.Dispatcher.init Dispatcher initialized");
            }

            else if (target.contains("web.xml")) {
                 out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                 out.println("<web-app>");
                 out.println("  <context-param>");
                 out.println("    <param-name>db.host</param-name>");
                 out.println("    <param-value>192.168.1.51</param-value>");
                 out.println("  </context-param>");
                 out.println("</web-app>");
            }
            else if (target.contains("tomcat-users.xml")) {
                out.println("<?xml version='1.0' encoding='utf-8'?>");
                out.println("<tomcat-users>");
                out.println("  <user username=\"tomcat\" password=\"GTC_Admin_2023\" roles=\"manager-gui\"/>");
                out.println("</tomcat-users>");
            }
            else if (target.contains(".env")) {
                out.println("APP_ENV=production");
                out.println("DB_HOST=192.168.1.51");
                out.println("DB_DATABASE=gtc_main");
                out.println("DB_USERNAME=gtc_service");
                out.println("DB_PASSWORD=Industrial_S3cur1ty!");
            }

            else if (target.contains(".bash_history")) {
                out.println("cd /opt/gtc_sys/logs");
                out.println("tail -f sys.log");
                out.println("sudo systemctl restart tomcat9");
                out.println("exit");
            }

            else if (target.startsWith("http://") || target.startsWith("https://")) {
                out.println("<span class='error'>Erreur: Impossible d'établir la connexion (Firewall restrictif).</span>");
            }
            
            else if (target.contains("sys.log") || !target.contains("..")) {
                out.println("[2024-01-22 08:00:01] INFO  SystemBoot - GTC Server Started v2.3");
                out.println("[2024-01-22 08:00:05] INFO  DatabaseManager - Connected to PostgreSQL (192.168.1.51:5432)");
                out.println("[2024-01-22 08:00:10] INFO  ModbusMaster - Initializing serial interface /dev/ttyUSB0");
                out.println("");
                out.println("[2024-01-22 08:05:22] ERROR ModbusConnector - Connection refused to 10.0.0.5:502");
                out.println("[2024-01-22 08:05:25] WARN  ModbusConnector - Retrying connection to Slave #4...");
                out.println("[2024-01-22 08:06:00] INFO  ModbusConnector - Connection established with Slave #4");
                out.println("");
                out.println("[2024-01-22 09:12:10] INFO  AuthService - User 'technicien' logged in from 192.168.1.104");
                out.println("[2024-01-22 09:15:00] INFO  Dashboard - View requested: 'Main HVAC Overview'");
                out.println("");
                out.println("[2024-01-22 10:45:01] <span class='warn'>WARN  TempSensor - Zone_B (AHU-2) reading 26.5°C - Threshold exceeded (Set: 24.0°C)</span>");
                out.println("[2024-01-22 10:45:02] INFO  AutoCorrect - Triggering Cooling_Coil_Valve to 85% open");
                out.println("[2024-01-22 11:00:00] INFO  TempSensor - Zone_B (AHU-2) stabilized at 24.2°C");
                out.println("");
                out.println("[2024-01-22 12:00:00] INFO  Scheduler - Executing daily_maintenance_task");
                out.println("[2024-01-22 14:00:05] <span class='error'>ERROR BackupService - Failed to write to /mnt/nas_backup/daily/ (Permission Denied)</span>");
                out.println("[2024-01-22 14:00:06] WARN  BackupService - Local backup created instead at /opt/gtc_sys/backups/fallback.zip");
                out.println("");
                out.println("[2024-01-22 15:30:45] INFO  Security - SSL Certificate will expire in 14 days");
                out.println("[2024-01-22 16:00:00] INFO  System - Routine health check passed");
            }
            
            else {
                out.println("java.io.FileNotFoundException: " + filename + " (No such file or directory)");
                out.println("\tat java.io.FileInputStream.open0(Native Method)");
                out.println("\tat java.io.FileInputStream.open(FileInputStream.java:195)");
                out.println("\tat org.apache.jsp.Visualiseur_jsp._jspService(Visualiseur_jsp.java:142)");
            }

        } else {
            out.println("<span class='info'>Système prêt. Sélectionnez un fichier de log à visualiser.</span>");
            out.println("Répertoire courant : /var/log/gtc/");
        }
    %>
    </div>

    <a href="<s:url action='index' namespace='/' />" class="back-link">
        &larr; Retour au panneau principal
    </a>
</div>

</body>
</html>
