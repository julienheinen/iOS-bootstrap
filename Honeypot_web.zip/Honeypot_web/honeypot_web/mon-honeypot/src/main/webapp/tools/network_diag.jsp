<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.io.*" %>
<%@ page import="java.util.Date" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ taglib prefix="s" uri="/struts-tags" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Diagnostic Réseau</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f0f2f5; padding: 20px; color: #333; }
        .container { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 800px; margin: auto; }
        h2 { border-bottom: 3px solid #fecb00; padding-bottom: 10px; margin-top: 0; }
        .console { background: #000; color: #00ff00; padding: 15px; border-radius: 4px; height: 300px; overflow-y: auto; font-family: monospace; font-size: 13px; }
        .controls { background: #e9ecef; padding: 15px; border-radius: 4px; margin-bottom: 20px; border: 1px solid #ddd; }
        input[type="text"] { width: 60%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        input[type="submit"] { padding: 8px 20px; background-color: #002147; color: white; border: none; border-radius: 4px; cursor: pointer; }
        input[type="submit"]:hover { background-color: #003366; }
        .back-link { display: block; margin-top: 20px; color: #002147; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <h2>Outil de Diagnostic Réseau (Ping)</h2>

    <div class="controls">
        <form action="" method="get">
            <label>Adresse IP cible : </label>
            <%-- Protection XSS basique pour l'affichage dans l'input --%>
            <input type="text" name="ip" placeholder="ex: 127.0.0.1" value="<%= request.getParameter("ip") != null ? request.getParameter("ip").replace("\"", "&quot;") : "" %>">
            <input type="submit" value="Tester la connexion">
        </form>
    </div>

    <div class="console">
        <%
            String rawIp = request.getParameter("ip");
            
            if (rawIp != null && !rawIp.trim().isEmpty()) {
                
                try {
                    String ipAddress = request.getHeader("X-Forwarded-For");
                    if (ipAddress == null) {
                        ipAddress = request.getRemoteAddr();
                    }

                    FileWriter fw = new FileWriter("/var/log/commandes.log", true);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                    fw.write("{" 
                    + "\"timestamp\":\"" + sdf.format(new Date()) + "\", "
                    + "\"app\":\"web-app-ping\", "
                    + "\"ip\":\"" + ipAddress + "\", "
                    + "\"event\":\"PING_COMMAND\", "
                    + "\"CMD\":\"" + rawIp.replace("\"", "\\\"") + "\""
                    + "}\n");
                    
                    fw.close();
                } catch (IOException e) {
                    // on ignore pour ne pas perturber l'utilisateur
                }

                
                //  latence
                try { Thread.sleep(800); } catch (InterruptedException e) {}

                String safeDisplay = rawIp.replace("<", "&lt;").replace(">", "&gt;");
                out.println("$ ping -c 3 " + safeDisplay);
                out.println("--------------------------------------------------");

                String cmd = rawIp.toLowerCase();
                
                boolean isInjection = cmd.contains(";") || cmd.contains("|") || cmd.contains("&") || cmd.contains("$") || cmd.contains("`") || cmd.contains("\n");

                if (!isInjection) {
                    out.println("PING " + safeDisplay + " (" + safeDisplay + ") 56(84) bytes of data.");
                    out.println("64 bytes from " + safeDisplay + ": icmp_seq=1 ttl=64 time=0.04 ms");
                    out.println("64 bytes from " + safeDisplay + ": icmp_seq=2 ttl=64 time=0.05 ms");
                    out.println("64 bytes from " + safeDisplay + ": icmp_seq=3 ttl=64 time=0.04 ms");
                    out.println("\n--- " + safeDisplay + " ping statistics ---");
                    out.println("3 packets transmitted, 3 received, 0% packet loss, time 2003ms");
                } else {
                    
                    if (cmd.contains("whoami")) {
                        out.println("tomcat");
                    } 
                    else if (cmd.contains("ls -la") || cmd.contains("ls -al") || cmd.contains("ll")) {
                        out.println("total 32");
                        out.println("drwxr-x--- 4 tomcat tomcat 4096 Oct 10 10:00 .");
                        out.println("drwxr-xr-x 8 tomcat tomcat 4096 Sep 21 09:12 ..");
                        out.println("-rw-r----- 1 tomcat tomcat 2405 Oct 01 14:22 diagnostic.jsp");
                        out.println("-rw-r----- 1 tomcat tomcat  120 Sep 25 11:00 web.xml");
                    }
                    else if (cmd.contains("ls")) {
                        out.println("diagnostic.jsp  web.xml  META-INF  WEB-INF");
                    }
                    else if (cmd.contains("cat /etc/passwd")) {
                        out.println("root:x:0:0:root:/root:/bin/bash");
                        out.println("daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin");
                        out.println("tomcat:x:1001:1001::/opt/tomcat:/bin/false");
                    }
                    else if (cmd.contains("cat /etc/shadow")) {
                        out.println("cat: /etc/shadow: Permission denied");
                    }
                    else if (cmd.contains("pwd")) {
                        out.println("/opt/tomcat/webapps/NetworkTool");
                    }
                    else if (cmd.contains("id")) {
                        out.println("uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)");
                    }
                    else if (cmd.contains("uname -a")) {
                        out.println("Linux srv-db-02 4.15.0-142-generic #146-Ubuntu SMP Tue Apr 13 09:27:15 UTC 2021 x86_64 x86_64 x86_64 GNU/Linux");
                    }
                    else if (cmd.contains("wget") || cmd.contains("curl")) {
                        out.println("Connecting... failed: Network is unreachable.");
                    }
                    else {
                        String[] parts = safeDisplay.split(" ");
                        String fakeCmd = parts[parts.length-1];
                        if(fakeCmd.length() > 20) fakeCmd = "command";
                        out.println("bash: " + fakeCmd + ": command not found");
                    }
                }
            } else {
                out.println("Système prêt.");
            }
        %>
    </div>

    <a href="<s:url action='index' namespace='/' />" class="back-link">
        &larr; Retour au panneau principal
    </a>
</div>

</body>
</html>
