#!/bin/bash
# Script de backup journalier GTC
# TODO: Automatiser l'envoi vers le NAS

DATE=$(date +%Y%m%d)
echo "[INFO] Starting backup for $DATE" >> /var/log/gtc_hvac/backup.log
tar -czf /opt/gtc_sys/backups/db_$DATE.tar.gz /var/lib/mysql 2>/dev/null
echo "[INFO] Backup completed." >> /var/log/gtc_hvac/backup.log
