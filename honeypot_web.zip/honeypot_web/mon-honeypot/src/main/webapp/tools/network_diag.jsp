<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.io.*" %>
<%@ taglib prefix="s" uri="/struts-tags" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Diagnostic Réseau</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f0f2f5; padding: 20px; color: #333; }
        .container { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 800px; margin: auto; }
        h2 { border-bottom: 3px solid #fecb00; padding-bottom: 10px; margin-top: 0; }
        .console { background: #000; color: #00ff00; padding: 15px; border-radius: 4px; height: 300px; overflow-y: auto; font-family: monospace; font-size: 13px; }
        .controls { background: #e9ecef; padding: 15px; border-radius: 4px; margin-bottom: 20px; border: 1px solid #ddd; }
        input[type="text"] { width: 60%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        input[type="submit"] { padding: 8px 20px; background-color: #002147; color: white; border: none; border-radius: 4px; cursor: pointer; }
        input[type="submit"]:hover { background-color: #003366; }
        .back-link { display: block; margin-top: 20px; color: #002147; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <h2>Outil de Diagnostic Réseau (Ping)</h2>

    <div class="controls">
        <form action="" method="get">
            <label>Adresse IP cible : </label>
            <input type="text" name="ip" placeholder="ex: 127.0.0.1" value="<%= request.getParameter("ip") != null ? request.getParameter("ip") : "" %>">
            <input type="submit" value="Tester la connexion">
        </form>
    </div>

    <div class="console">
        <%
            String ip = request.getParameter("ip");
            if (ip != null && !ip.trim().isEmpty()) {
                out.println("$ ping -c 3 " + ip);
                out.println("--------------------------------------------------");
                
                try {
                    String[] cmd = { "/bin/sh", "-c", "ping -c 3 " + ip };
                    
                    Process p = Runtime.getRuntime().exec(cmd);
                    
                    BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
                    String s;
                    while ((s = stdInput.readLine()) != null) {
                        out.println(s);
                    }
                    
                    BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                    while ((s = stdError.readLine()) != null) {
                        out.println("STDERR: " + s);
                    }
                    
                } catch (Exception e) {
                    out.println("Erreur d'exécution : " + e.getMessage());
                }
            } else {
                out.println("Prêt. Veuillez entrer une adresse IP.");
            }
        %>
    </div>

    <a href="<s:url action='index' namespace='/' />" class="back-link">
        &larr; Retour au panneau principal
    </a>
</div>

</body>
</html>
