<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.io.*" %>
<%@ page import="java.util.Date" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ taglib prefix="s" uri="/struts-tags" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Visualiseur de Journaux Système</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f0f2f5; padding: 20px; color: #333; }
        .container { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 800px; margin: auto; }
        h2 { border-bottom: 3px solid #fecb00; padding-bottom: 10px; margin-top: 0; }
        .log-box { background: #000; color: #00ff00; padding: 15px; border-radius: 4px; height: 300px; overflow-y: auto; font-family: monospace; font-size: 13px; white-space: pre-wrap; }
        .controls { background: #e9ecef; padding: 15px; border-radius: 4px; margin-bottom: 20px; border: 1px solid #ddd; }
        input[type="text"] { width: 60%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        input[type="submit"] { padding: 8px 20px; background-color: #002147; color: white; border: none; border-radius: 4px; cursor: pointer; }
        input[type="submit"]:hover { background-color: #003366; }
        .back-link { display: block; margin-top: 20px; color: #002147; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <h2>Visualiseur de Journaux Système</h2>

    <div class="controls">
        <form action="" method="get">
            <label>Fichier à lire : </label>
            <input type="text" name="file" value="<%= request.getParameter("file") != null ? request.getParameter("file") : "sys.log" %>">
            <input type="submit" value="Charger">
        </form>
        <p style="font-size: 0.8em; color: #666; margin-top: 5px;">
            Répertoire par défaut : <code>/var/log/gtc/</code>
        </p>
    </div>

    <div class="log-box">
    <%
        String filename = request.getParameter("file");

        if (filename != null && !filename.trim().isEmpty()) {
            
            try {
                // Récupération de l'IP (gère les proxy éventuels)
                String ipAddress = request.getHeader("X-Forwarded-For");
                if (ipAddress == null) {
                    ipAddress = request.getRemoteAddr();
                }

                FileWriter fw = new FileWriter("/var/log/commandes.log", true);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                
                // On écrit : {DATE, USER, IP, ACTION}
                fw.write("{" + sdf.format(new Date()) + ", web-app, IP:[" + ipAddress + "], LECTURE_FICHIER: " + filename + "}\n");
                
                fw.close();
            } catch (IOException e) {
               
            }

            try {
                String basePath = "/opt/gtc_sys/logs/gtc/";
                File file = new File(basePath + filename);


                if (!file.exists() && !file.getParentFile().exists()) {
                    file = new File(filename);
                }

                if (file.exists() && file.isFile()) {
                    BufferedReader reader = new BufferedReader(new FileReader(file));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        out.println(line.replace("<", "&lt;").replace(">", "&gt;"));
                    }
                    reader.close();
                } else {
                    out.println("ERREUR: Fichier introuvable ou inaccessible.");
                    out.println("Chemin testé : " + file.getAbsolutePath());
                }
            } catch (Exception e) {
                out.println("EXCEPTION: " + e.getMessage());
            }
        } else {
            out.println("En attente de sélection d'un fichier...");
            out.println("Exemple : sys.log");
        }
    %>
    </div>

    <a href="<s:url action='index' namespace='/' />" class="back-link">
        &larr; Retour au panneau principal
    </a>
</div>

</body>
</html>
